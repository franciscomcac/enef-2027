# ENEF 2027

Vite + TypeScript build of the ENEF 2027 site.

```bash
npm install
npm run dev      # local dev server
npm run build    # type-check + production build to dist/
```

## Structure
- `index.html` — page markup
- `src/styles.css` — all styles
- `src/copy.ts` — PT/EN translations
- `src/app.ts` — core site logic (rendering, packs state, schedule, FAQ, modal, reveals, cursor)
- `src/fx.ts` — particles, cursor trail, camera moves, flythrough
- `src/packs-ring.ts` — 3D packs ring + pinned scroll
- `src/reg-modal.ts` — registration modal animation
- `src/map.ts` — Leaflet map
- `public/` — static files served as-is (`assets/`, `contactos.html`)

GSAP and Leaflet come from npm (`src/globals.ts`). Ported modules still start with `// @ts-nocheck`; remove it per file to type them.

## Deploy
Vercel auto-detects Vite (build `npm run build`, output `dist`).
