// Import order = execution order (same as the original script tag order).
import './globals';
import './app';
import './fx';
import './packs-ring';
import './reg-modal';
import './map';
