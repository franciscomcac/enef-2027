// @ts-nocheck
// Packs: 3D ticket ring, drag/arrow nav, pinned crane shot + scroll stepping.
// Ported verbatim from the single-file build; remove @ts-nocheck and add types module by module.
(function(){
  var stage=document.getElementById("pkStage"), cam=document.getElementById("pkCam"), tilt=document.getElementById("pkTilt"), ring=document.getElementById("packList"), orbit=document.getElementById("pkOrbit");
  if(!stage||!ring) return;
  var N=5, STEP=360/N, reduce=matchMedia("(prefers-reduced-motion: reduce)").matches, G=window.gsap;
  var spin=0, R=400, cur=0, rot={a:0}, punch={z:0,r:0}, mx=0, my=0, tx=0, ty=0;
  function selIndex(){ var rows=ring.querySelectorAll(".pack-row"); for(var i=0;i<rows.length;i++) if(rows[i].classList.contains("on")) return i; return 0; }
  function layout(){
    var slot=ring.querySelector(".pk-slot"); var w=slot?slot.offsetWidth:0;
    if (!w){ requestAnimationFrame(layout); return; }
    R=Math.round(w*1.32);
    ring.querySelectorAll(".pk-slot").forEach(function(s,i){ s.style.transform="rotateY("+(i*STEP)+"deg) translateZ("+R+"px)"; });
    var d=R*2+w*.6; orbit.style.cssText="width:"+d+"px;height:"+d+"px;margin:"+(-d/2)+"px 0 0 "+(-d/2)+"px;transform:translateY("+(w*.86*1.46/1.46)+"px) rotateX(90deg)";
  }
  new MutationObserver(layout).observe(ring,{childList:true});
  layout(); addEventListener("resize", layout);
  if (window.ResizeObserver) new ResizeObserver(layout).observe(stage);
  if (document.fonts && document.fonts.ready) document.fonts.ready.then(layout);
  addEventListener("load", layout);
  function go(i, instant){
    var target=-i*STEP, delta=((target-rot.a)%360+540)%360-180, dir=Math.sign(delta)||1;
    cur=i; document.getElementById("pkCount").textContent="0"+(i+1)+" / 0"+N;
    if (!G||instant||reduce){ rot.a+=delta; return; }
    G.to(rot,{a:rot.a+delta,duration:1.15,ease:"power3.inOut",overwrite:true});
    G.timeline({overwrite:true}).to(punch,{z:-R*.9,r:-dir*5,duration:.5,ease:"power2.out"}).to(punch,{z:0,r:0,duration:.9,ease:"expo.out"});
    var card=ring.querySelectorAll(".pack-row")[i];
    if (card) G.fromTo(card,{rotateX:0},{keyframes:[{rotateX:-12,duration:.4,ease:"power2.out"},{rotateX:0,duration:.9,ease:"elastic.out(1,.4)"}],delay:.7});
  }
  window.__packBurst=function(i){ go(i); };
  go(selIndex(), true);
  function pick(i){ i=((i%N)+N)%N; var b=ring.querySelectorAll(".pack-row")[i]; if(b) b.click(); }
  document.getElementById("pkPrev").addEventListener("click",function(){ pick(cur-1); });
  document.getElementById("pkNext").addEventListener("click",function(){ pick(cur+1); });
  stage.addEventListener("keydown",function(e){ if(e.key==="ArrowLeft"){pick(cur-1);e.preventDefault();} if(e.key==="ArrowRight"){pick(cur+1);e.preventDefault();} });
  // drag to spin
  var down=null, moved=false;
  stage.addEventListener("pointerdown",function(e){ if(e.target.closest(".pk-nav")) return; down={x:e.clientX,a:rot.a}; moved=false; if(G) G.killTweensOf(rot); });
  addEventListener("pointermove",function(e){
    var r=stage.getBoundingClientRect(); mx=(e.clientX-r.left)/r.width-.5; my=(e.clientY-r.top)/r.height-.5;
    if(!down) return; var dx=e.clientX-down.x; if(Math.abs(dx)>6){ moved=true; stage.classList.add("drag"); }
    rot.a=down.a+dx*.32;
  });
  addEventListener("pointerup",function(){
    if(!down) return; var wasMoved=moved; down=null; stage.classList.remove("drag");
    if(wasMoved){ var i=((Math.round(-rot.a/STEP)%N)+N)%N; if(i===cur) go(i); else pick(i); }
  });
  stage.addEventListener("click",function(e){ if(moved){ e.stopPropagation(); e.preventDefault(); moved=false; } },true);
  // render loop: mouse-driven camera orbit + idle drift + depth shading
  var t0=performance.now(), vis=false, rafId=0;
  new IntersectionObserver(function(en){ vis=en[0].isIntersecting; if(vis&&!rafId) rafId=requestAnimationFrame(loop); }).observe(stage);
  function loop(now){
    var t=(now-t0)/1000;
    tx+=(mx-tx)*.06; ty+=(my-ty)*.06;
    var idle=reduce?0:Math.sin(t*.6);
    tilt.style.transform="translateZ("+punch.z+"px) rotateX("+(-6-ty*10)+"deg) rotateY("+(tx*16+idle*2)+"deg) rotateZ("+punch.r+"deg)";
    ring.style.transform="translateZ("+(-R)+"px) translateY("+(idle*6)+"px) rotateY("+(rot.a+spin)+"deg)";
    var slots=ring.children;
    for(var i=0;i<slots.length;i++){ var c=Math.cos((i*STEP+rot.a+spin)*Math.PI/180); slots[i].style.opacity=(.45+.55*Math.max(0,c)).toFixed(3); }
    rafId = vis ? requestAnimationFrame(loop) : 0;
  }
  // one pinned timeline: first the crane shot (overhead -> eye level, ring spins in), then each scroll step = one pack
  if (G&&window.ScrollTrigger&&!reduce){
    var grid=document.getElementById("packsStage"), lastI=-1, INTRO=.22;
    var steps=[0]; for(var k=0;k<N;k++) steps.push(INTRO+k*(1-INTRO)/(N-1));
    function crane(p){
      var e=1-Math.pow(1-Math.min(1,p/INTRO),3), k=1-e;
      cam.style.transform="translate3d(0,"+(-140*k)+"px,"+(-500*k)+"px) rotateX("+(62*k)+"deg) rotateZ("+(-8*k)+"deg)";
      spin=300*k;
    }
    crane(0);
    ScrollTrigger.create({ trigger:grid, start:"bottom bottom", end:function(){ return "+="+Math.round(innerHeight*3.2); },
      pin:true, anticipatePin:1, refreshPriority:1,
      snap:{ snapTo:steps, duration:{min:.25,max:.7}, delay:.08, ease:"power2.inOut" },
      onUpdate:function(self){
        var p=self.progress; crane(p);
        if(p<INTRO*.6) return;
        var i=Math.max(0,Math.min(N-1,Math.round((p-INTRO)/(1-INTRO)*(N-1))));
        if(i!==lastI){ lastI=i; if(i!==cur) pick(i); }
      } });
    ScrollTrigger.refresh();
  }
  stage.tabIndex=0;
})();
