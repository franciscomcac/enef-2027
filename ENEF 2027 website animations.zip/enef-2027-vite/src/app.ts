// @ts-nocheck
// Core site: i18n rendering, packs state, schedule, FAQ, registration modal, reveals, cursor.
// Ported verbatim from the single-file build; remove @ts-nocheck and add types module by module.
import { COPY as __COPY } from './copy';
(function(){
  "use strict";
  // shared motion signature: the one eased curve already used for this site's mechanical
  // reveals (faq accordion, modal progress bar, activity flood) — reused here for scroll-
  // triggered entrances too, so every "this appears now" moment reads as one motion language
  // instead of a handful of similar-but-different easings.
  var EASE = "cubic-bezier(.2,.8,.25,1)";
  var SPECTRUM = [
    { color:"#C4362F", fg:"#F2EFE7" },
    { color:"#E8A93C", fg:"#14161A" },
    { color:"#2C93A8", fg:"#F2EFE7" },
    { color:"#4B3FA6", fg:"#F2EFE7" }
  ];
  var NAMES = ["Marta Nunes","Rui Carvalho","Inês Batista","Tomás Ferreira","Beatriz Lopes","Diogo Sousa","Carolina Melo","André Pinto"];
  var LAB_IMG = "assets/photo5.jpg";
  var BLUE_IMG = "assets/photo6.jpg";
  var CAMPUS_IMG = "assets/photo7.jpg";

  var COPY = __COPY;

  var lang = "pt";
  var state = { pack:0, faq:-1, regOpen:false, regStep:0, form:{name:"",email:"",inst:""} };
  var sponsorNames = ["Physis","Técnico","FCT","Gulbenkian","IPFN","SPF"];

  function t(){ return COPY[lang]; }
  function pad(n){ return String(n).padStart(2,"0"); }

  function setLangUI(){
    document.getElementById("langPt").style.color = lang==="pt" ? "var(--accent)" : "rgba(20,22,26,.42)";
    document.getElementById("langEn").style.color = lang==="en" ? "var(--accent)" : "rgba(20,22,26,.42)";
    document.documentElement.lang = lang;
  }

  function applyI18n(){
    document.querySelectorAll("[data-i18n]").forEach(function(el){
      var val = t()[el.getAttribute("data-i18n")];
      if (typeof val !== "string") return;
      el.innerHTML = val.split("\n").join("<br>");
    });
  }

  function renderDayChips(){
    var wk = t().dayWeek;
    var html = SPECTRUM.map(function(sp,i){
      return '<div class="chip" style="background:'+sp.color+';color:'+sp.fg+'"><div class="num display">'+(11+i)+'</div><div class="nm mono">'+wk[i]+'</div></div>';
    }).join("");
    document.getElementById("dayChips").innerHTML = html;
  }

  function renderDayStripe(){
    document.getElementById("dayStripe").innerHTML = SPECTRUM.map(function(sp){ return '<span style="background:'+sp.color+'"></span>'; }).join("");
  }

  function renderTicker(){
    var items = [];
    for (var r=0;r<5;r++){ items = items.concat(t().ticker); }
    document.getElementById("tickerTrack").innerHTML = items.map(function(x,i){
      var c = (i%3===1) ? "#1F44FF" : "#F2EFE7";
      return '<span style="color:'+c+'">'+x+'</span>';
    }).join("");
    document.getElementById("apoiosTrack").innerHTML = [].concat(sponsorNames,sponsorNames,sponsorNames,sponsorNames).map(function(n){return '<span>'+n+'</span>';}).join("");
  }

  function renderActivities(){
    var tilts = ["-1.4deg","1.2deg","-1deg"];
    document.getElementById("activitiesList").innerHTML = '<div style="border-top:1px solid var(--paper-faint)">' + t().activities.map(function(a,i){
      return '<div class="act-row" data-reveal>'+
        '<div class="act-flood"></div>'+
        '<div class="act-inner">'+
          '<span class="act-num mono">0'+(i+1)+'</span>'+
          '<div><h3 class="act-title display">'+a.title+'</h3><span class="act-tag mono">'+a.tag+'</span></div>'+
          '<p class="act-body">'+a.body+'</p>'+
          '<div class="act-photo" style="transform:rotate('+tilts[i]+')"><img src="'+a.img+'" alt="" loading="lazy" decoding="async" width="759" height="429"></div>'+
        '</div>'+
      '</div>';
    }).join("") + '</div>';
    document.getElementById("statsRow").innerHTML = t().stats.map(function(s){
      return '<span><b>'+s[0]+'</b> <span class="lbl">'+s[1]+'</span></span>';
    }).join("");
  }

  // selecting a pack only toggles the "on" class on the existing rows (same reasoning as
  // toggleFaq: a full re-render would recreate the nodes and skip the CSS transition on
  // .pack-row.on). The summary sidebar's content genuinely changes per pack, so that part
  // still rebuilds — but animates in with GSAP explicitly rather than relying on a CSS
  // transition across a node swap.
  function selectPack(i){
    state.pack = i;
    var rows = document.querySelectorAll("#packList .pack-row");
    rows.forEach(function(btn, idx){ btn.classList.toggle("on", idx===i); });
    if (window.gsap && rows[i]){
      gsap.fromTo(rows[i], { scale:.985 }, { scale:1, duration:.4, ease:"back.out(2.4)", overwrite:true });
    }
    updatePackSummary();
  }
  var SEG = ["#1F44FF","#E8A93C","#2C93A8","#7B6FE0"];
  var __lastTotal = null;
  function updatePackSummary(){
    var ap = t().packs[state.pack];
    var itemsEl = document.getElementById("psItems");
    itemsEl.innerHTML = t().incl.map(function(label,i){
      var on = ap.includes.indexOf(i) > -1;
      return '<div class="ps-item'+(on?"":" off")+'" style="--c:'+SEG[i]+'"><span class="ps-sw"></span><span class="ps-lbl" style="font-size:17px;flex:1">'+label+'</span><span class="mono" style="font-size:10px;letter-spacing:.14em;opacity:.6">'+(on?"✓":"—")+'</span></div>';
    }).join("");
    var totalEl = document.getElementById("psTotal");
    var target = parseInt(ap.price.replace(/\D/g,""),10);
    if (window.gsap && __lastTotal !== null && __lastTotal !== target){
      var o = { v:__lastTotal };
      gsap.to(o, { v:target, duration:.7, ease:"power3.out", overwrite:true, onUpdate:function(){ totalEl.textContent = ap.price.replace(/\d+/, Math.round(o.v)); } });
    } else totalEl.textContent = ap.price;
    __lastTotal = target;
    if (window.gsap){
      gsap.from(itemsEl.children, { opacity:0, x:-14, duration:.45, stagger:.05, ease:EASE });
      gsap.fromTo("#psTotal", { yPercent:40, opacity:.2 }, { yPercent:0, opacity:1, duration:.6, ease:"expo.out", overwrite:"auto" });
      gsap.fromTo(".ps-cta", { scale:.96 }, { scale:1, duration:.5, ease:"back.out(3)", overwrite:"auto" });
    }
    if (window.__packBurst) window.__packBurst(state.pack);
  }
  function renderPacks(){
    var packs = t().packs;
    var incl = t().incl;
    document.getElementById("packList").innerHTML = packs.map(function(p,i){
      var on = i===state.pack;
      return '<div class="pk-slot" data-i="'+i+'"><button class="pack-row'+(on?" on":"")+'" data-i="'+i+'">'+
        '<span class="pk-top mono"><span>'+p.code+'</span><span>'+p.includes.length+'/4</span></span>'+
        '<span class="pack-name">'+p.name+'</span>'+
        '<span class="pk-incl">'+incl.map(function(l,k){ var y=p.includes.indexOf(k)>-1; return '<span class="'+(y?"":"off")+'" style="--c:'+SEG[k]+'"><i></i>'+l+'</span>'; }).join("")+'</span>'+
        '<span class="pk-perf"></span>'+
        '<span class="pack-price">'+p.price+'</span>'+
      '</button><div class="pk-back" aria-hidden="true">'+p.code+'</div></div>';
    }).join("");
    document.querySelectorAll(".pack-row").forEach(function(btn){
      btn.addEventListener("click", function(){ selectPack(parseInt(btn.getAttribute("data-i"),10)); });
    });
    updatePackSummary();
  }

  function renderSchedule(){
    var wk = t().dayWeek, labels = t().dayLabels, sched = t().schedule;
    document.getElementById("railTrack").innerHTML = SPECTRUM.map(function(sp,i){
      return '<div class="day-col">'+
        '<div class="day-col-head"><span class="dd" style="background:'+sp.color+'"></span><span class="wk mono">'+wk[i]+'</span><span class="lb display">'+labels[i]+'</span></div>'+
        sched[i].map(function(s){
          return '<div class="slot"><div class="time mono">'+s[0]+'</div><div class="title">'+s[1]+'</div><div class="place mono">'+s[2]+'</div></div>';
        }).join("")+
      '</div>';
    }).join("");
  }

  function renderTeam(){
    var roles = t().roles;
    document.getElementById("teamList").innerHTML = NAMES.map(function(name,i){
      return '<div class="team-row"><span class="team-idx mono">'+pad(i+1)+'</span><span class="team-name display">'+name+'</span><span class="team-role mono">'+roles[i]+'</span></div>';
    }).join("");
    if (window.__rebuildTeamLadder) window.__rebuildTeamLadder();
  }

  // toggling only flips the "open" class on the existing nodes rather than re-rendering
  // the list — a full innerHTML replace destroys and recreates the nodes, which silently
  // skips the CSS grid-rows/plus-rotate transitions (no "previous state" to animate from)
  // and made the accordion snap open instead of easing, dragging everything below it down
  // in one jump. ScrollTrigger.refresh() afterwards recalculates trigger positions for
  // anything scroll-scrubbed further down the page (e.g. the venue photo's parallax),
  // which otherwise keeps using stale pixel offsets from before the layout shifted.
  function toggleFaq(i){
    state.faq = state.faq===i ? -1 : i;
    document.querySelectorAll("#faqList .faq-item").forEach(function(el, idx){
      el.classList.toggle("open", idx===state.faq);
    });
    if (window.ScrollTrigger){
      setTimeout(function(){ ScrollTrigger.refresh(); }, 420);
    }
  }
  function renderFaqs(){
    document.getElementById("faqList").innerHTML = t().faqs.map(function(f,i){
      var open = state.faq===i;
      return '<div class="faq-item'+(open?" open":"")+'" data-reveal>'+
        '<button class="faq-q" data-i="'+i+'"><span style="flex:1">'+f[0]+'</span><span class="plus">+</span></button>'+
        '<div class="faq-body"><div><p>'+f[1]+'</p></div></div>'+
      '</div>';
    }).join("");
    document.querySelectorAll(".faq-q").forEach(function(btn){
      btn.addEventListener("click", function(){ toggleFaq(parseInt(btn.getAttribute("data-i"),10)); });
    });
  }

  function renderFooter(){
    document.getElementById("footCols").innerHTML = t().footCols.map(function(c){
      return '<div class="foot-col"><div class="head mono">'+c[0]+'</div><div class="lines">'+c[1].map(function(l){return "<div>"+l+"</div>";}).join("")+'</div></div>';
    }).join("");
  }

  function renderCountdown(){
    var target = new Date("2027-02-11T14:00:00").getTime();
    var diff = Math.max(0, target - Date.now());
    var s = Math.floor(diff/1000);
    var nums = [Math.floor(s/86400), Math.floor(s/3600)%24, Math.floor(s/60)%60, s%60];
    var units = ["d","h","min","s"];
    document.getElementById("countdownGrid").innerHTML = nums.map(function(n,i){
      return '<div class="cd-cell"><div class="row"><span class="v">'+(i===0?n:pad(n))+'</span><span class="u">'+units[i]+'</span></div></div>';
    }).join("");
  }

  // registration modal
  function openReg(){ state.regOpen = true; state.regStep = 0; renderReg(); document.getElementById("regModal").classList.add("open"); if (window.__regOpenFx) window.__regOpenFx(); }
  function closeReg(){ state.regOpen = false; var m=document.getElementById("regModal"); if (window.__regCloseFx) window.__regCloseFx(function(){ if(!state.regOpen) m.classList.remove("open"); }); else m.classList.remove("open"); }
  function renderReg(){
    var r = t().reg, step = state.regStep, packs = t().packs, ap = packs[state.pack];
    document.getElementById("regStepLabel").textContent = (step+1)+"/3 · "+r.steps[step];
    document.getElementById("regProgress").style.width = ((step+1)/3*100)+"%";
    document.getElementById("regTitle").textContent = [r.t1,r.t2,r.t3][step];
    document.getElementById("regStep0").style.display = step===0 ? "" : "none";
    document.getElementById("regStep1").style.display = step===1 ? "" : "none";
    document.getElementById("regStep2").style.display = step===2 ? "" : "none";
    if (step===0){
      var labs = ["regL0","regL1","regL2"], flds = ["regF0","regF1","regF2"], keys=["name","email","inst"];
      r.fields.forEach(function(fd,i){
        document.getElementById(labs[i]).textContent = fd[0];
        var input = document.getElementById(flds[i]);
        input.placeholder = fd[1];
        input.value = state.form[keys[i]];
        input.oninput = function(){ state.form[keys[i]] = input.value; };
      });
    }
    if (step===1){
      document.getElementById("regStep1").innerHTML = packs.map(function(p,i){
        var on = i===state.pack;
        return '<button class="modal-pack-row'+(on?" on":"")+'" data-i="'+i+'"><span class="mono" style="font-size:10px;opacity:.6">'+p.code+'</span><span style="flex:1">'+p.name+'</span><span class="mono" style="font-weight:700;font-size:14px">'+p.price+'</span></button>';
      }).join("");
      document.querySelectorAll("#regStep1 .modal-pack-row").forEach(function(btn){
        btn.addEventListener("click", function(){ state.pack = parseInt(btn.getAttribute("data-i"),10); renderPacks(); renderReg(); });
      });
    }
    if (step===2){
      document.getElementById("regDoneBody").textContent = r.doneBody;
      document.getElementById("sumName").textContent = state.form.name || r.fields[0][1];
      document.getElementById("sumEmail").textContent = state.form.email || r.fields[1][1];
      document.getElementById("sumPack").textContent = ap.code+" · "+ap.name+" · "+ap.price;
    }
    var backBtn = document.getElementById("regBack");
    backBtn.style.display = (step>0 && step<2) ? "" : "none";
    backBtn.textContent = t().back;
    var nextBtn = document.getElementById("regNext");
    nextBtn.textContent = step===0 ? r.next : step===1 ? r.finish : r.close;
  }
  document.getElementById("regClose").addEventListener("click", closeReg);
  document.getElementById("regBack").addEventListener("click", function(){ state.regStep = Math.max(0,state.regStep-1); renderReg(); if (window.__regStepFx) window.__regStepFx(-1); });
  document.getElementById("regNext").addEventListener("click", function(){
    if (state.regStep < 2){ state.regStep++; renderReg(); if (window.__regStepFx) window.__regStepFx(1); } else { closeReg(); }
  });
  document.getElementById("ctaNav").addEventListener("click", openReg);
  document.getElementById("ctaFinal").addEventListener("click", openReg);
  document.getElementById("ctaPack").addEventListener("click", openReg);

  document.getElementById("langBtn").addEventListener("click", function(){
    lang = lang==="pt" ? "en" : "pt";
    renderAll();
  });

  // mobile nav: the link row collapses behind this hamburger toggle below 880px
  (function bindNavToggle(){
    var toggle = document.getElementById("navToggle");
    var links = document.querySelector("nav .links");
    if (!toggle || !links) return;
    function closeMenu(){
      links.classList.remove("open");
      toggle.classList.remove("active");
      toggle.setAttribute("aria-expanded", "false");
    }
    toggle.addEventListener("click", function(){
      var open = links.classList.toggle("open");
      toggle.classList.toggle("active", open);
      toggle.setAttribute("aria-expanded", open ? "true" : "false");
    });
    links.querySelectorAll("a").forEach(function(a){
      a.addEventListener("click", closeMenu);
    });
    window.addEventListener("resize", function(){
      if (window.innerWidth > 880) closeMenu();
    });
  })();

  // keep --nav-h in sync with the sticky nav's real height, so the smooth-scrolled
  // anchor offset (scroll-margin-top, above) stays correct across the mobile/desktop
  // nav heights and after a font-load reflow
  (function trackNavHeight(){
    var nav = document.querySelector("nav");
    if (!nav) return;
    function apply(){ document.documentElement.style.setProperty("--nav-h", (nav.offsetHeight+14)+"px"); }
    apply();
    window.addEventListener("resize", apply);
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(apply);
  })();

  function renderAll(){
    setLangUI(); applyI18n(); renderDayChips(); renderDayStripe(); renderTicker();
    renderActivities(); renderPacks(); renderSchedule(); renderTeam(); renderFaqs(); renderFooter(); renderCountdown();
    if (state.regOpen) renderReg();
    if (window.__initReveal) window.__initReveal();
  }

  renderAll();
  setInterval(renderCountdown, 1000);

  // porthole band: glimpse of the same photography used elsewhere, through cut shapes
  (function(){
    var ph = document.getElementById("phLab");
    var pb = document.getElementById("phBlue");
    var pc = document.getElementById("phCampus");
    if (ph) ph.src = LAB_IMG;
    if (pb) pb.src = BLUE_IMG;
    if (pc) pc.src = CAMPUS_IMG;
  })();

  // schedule rail: native horizontal scroll, enhanced with mouse drag-to-scroll
  (function bindRailDrag(){
    var wrap = document.getElementById("railWrap");
    if (!wrap) return;
    var isDown = false, startX = 0, startScroll = 0, moved = false;
    wrap.addEventListener("pointerdown", function(e){
      isDown = true; moved = false; startX = e.clientX; startScroll = wrap.scrollLeft;
      wrap.classList.add("dragging");
      e.preventDefault();
    });
    window.addEventListener("pointermove", function(e){
      if (!isDown) return;
      var dx = e.clientX - startX;
      if (Math.abs(dx) > 4) moved = true;
      wrap.scrollLeft = startScroll - dx;
    });
    window.addEventListener("pointerup", function(){
      isDown = false; wrap.classList.remove("dragging");
    });
    wrap.addEventListener("click", function(e){ if (moved){ e.preventDefault(); e.stopPropagation(); } }, true);
  })();

  // ---- motion: Lenis + GSAP ScrollTrigger ----
  var reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  function safe(label, fn){
    try { fn(); }
    catch(e){ if (window.console) console.error("[enef:"+label+"]", e); }
  }

  if (!reduceMotion && window.gsap && window.ScrollTrigger){
    gsap.registerPlugin(ScrollTrigger);

    // always show everything at rest first — motion only enhances from here
    document.querySelectorAll("[data-reveal]").forEach(function(el){ el.style.opacity=1; });

    // intro reveal: mark fades in, an accent blob scales up to swallow the screen,
    // then recedes to hand off to the page — a designed transition, not a spinner.
    safe("intro", function(){
      var veil = document.getElementById("introVeil");
      var blob = document.getElementById("introBlob");
      var ring = document.getElementById("introRing");
      var word = document.getElementById("introWord");
      if (!veil || !blob || !ring || !word){ document.body.style.overflow=""; return; }
      clearTimeout(window.__introFailsafe);
      var reach = Math.max(window.innerWidth, window.innerHeight) * 1.7 / 64;
      var tl = gsap.timeline({
        onComplete: function(){
          if (veil.parentNode) veil.parentNode.removeChild(veil);
          document.body.style.overflow = "";
        }
      });
      tl.set(blob, { scale: 0, borderRadius:"50%" });
      tl.from([ring, word], { opacity:0, y:12, duration:.45, ease:"power2.out" })
        .to(blob, { scale:1, duration:.5, ease:"back.out(1.6)" }, "-=.15")
        .to([ring, word], { opacity:0, y:-10, duration:.35, ease:"power2.in" }, "+=.25")
        .to(blob, { scale: reach, duration:.85, ease:"power3.in", borderRadius:"0%" }, "-=.15")
        .to(veil, { opacity:0, duration:.4, ease:"power1.out" }, "-=.1");
    });

    // nav progress
    safe("navprogress", function(){
      ScrollTrigger.create({
        trigger: document.body, start: "top top", end: "max", scrub: true,
        onUpdate: function(self){ document.getElementById("progBar").style.width = (self.progress*100)+"%"; }
      });
    });

    // hero load-in
    safe("hero", function(){
      var wm = document.querySelectorAll("#heroWordmark .row span");
      gsap.set(wm, { opacity:0, y:"0.42em", rotate:2.5 });
      gsap.to(wm, { opacity:1, y:0, rotate:0, duration:.8, stagger:.07, ease:"back.out(1.4)", delay:.1 });
      gsap.from(".wm-aside", { opacity:0, y:16, duration:.8, delay:.75, ease:EASE });
      gsap.from(".hero-lead", { opacity:0, y:16, duration:.8, delay:.5, ease:EASE });
      gsap.from(".daychips .chip", { opacity:0, y:16, duration:.7, delay:.62, stagger:.06, ease:EASE });
      gsap.from(".venuerow", { opacity:0, y:16, duration:.8, delay:.7, ease:EASE });
    });

    // scope panel + hero depth: no pinning/scroll-jacking — the black ticker section
    // just stays put, exactly where it naturally sits. The parallax lives entirely on
    // the cream hero itself as you scroll normally past it: the card levels out of its
    // resting tilt and settles smaller, and the rest of the hero eases back, scales
    // down and fades slightly, like it's sinking away — tied 1:1 to scroll (scrub, not
    // a timed tween) over the hero's own natural height, no pin required.
    safe("parallax", function(){
      var content = document.querySelector(".hero-grid");
      var blobs = document.querySelector(".hero-blobs");
      ScrollTrigger.create({
        trigger: "#top", start: "top top", end: "bottom top", scrub: 1,
        onUpdate: function(self){
          var p = self.progress;
          gsap.set("#scopePanel", { rotate: -1+p, scale: 1-p*0.05, y: p*-14 });
          if (content) gsap.set(content, { scale: 1-p*0.07, y: p*-24, opacity: 1-p*0.45 });
          if (blobs) gsap.set(blobs, { opacity: 1-p*0.6 });
        }
      });
    });

    // hero parallax: cursor OR finger position shifts each depth layer by a different
    // amount, like a camera looking into a diorama (near layers move more than far ones).
    // Pointer events unify mouse and touch, so the same listener drives both — on a
    // phone this fires as a finger drags/scrolls across the hero, no hover required.
    safe("heroParallax", function(){
      var hero = document.getElementById("top");
      if (!hero) return;
      var layers = [
        { el: document.querySelector(".hb1"),      fx: 26, fy: 18 },
        { el: document.querySelector(".hb2"),       fx: -16, fy: 22 },
        { el: document.getElementById("scopeStack"),fx: 10, fy: 8 },
        { el: document.getElementById("heroWordmark"), fx: -6, fy: 4 }
      ].filter(function(l){ return !!l.el; });
      // quickTo builds one lightweight setter per property instead of spinning up a
      // brand-new tween on every pointermove — a mouse/trackpad can fire that event
      // at 120Hz+, far above the screen's redraw rate, so the old gsap.to-per-event
      // approach was doing many times more interpolation work than could ever be seen.
      layers.forEach(function(l){
        l.setX = gsap.quickTo(l.el, "x", { duration:.8, ease:"power3.out" });
        l.setY = gsap.quickTo(l.el, "y", { duration:.8, ease:"power3.out" });
      });
      // rAF-batch the raw events too: only the latest pointer position each frame is
      // ever applied, and the (layout-reading) getBoundingClientRect call moves off the
      // hot path into the frame callback, so it never runs more often than the screen
      // can actually show a new position.
      var pending = null, ticking = false;
      function apply(){
        ticking = false;
        if (!pending) return;
        var r = hero.getBoundingClientRect();
        var cx = ((pending.x - r.left) / r.width) * 2 - 1;
        var cy = ((pending.y - r.top) / r.height) * 2 - 1;
        pending = null;
        layers.forEach(function(l){ l.setX(cx*l.fx); l.setY(cy*l.fy); });
      }
      hero.addEventListener("pointermove", function(e){
        pending = { x: e.clientX, y: e.clientY };
        if (!ticking){ ticking = true; requestAnimationFrame(apply); }
      }, { passive:true });
      function resetHero(){
        pending = null;
        layers.forEach(function(l){ l.setX(0); l.setY(0); });
      }
      hero.addEventListener("pointerleave", resetHero);
      hero.addEventListener("pointerup", resetHero);
      hero.addEventListener("pointercancel", resetHero);
    });

    // porthole windows: each photo drifts behind its rim as the cursor OR a finger moves,
    // like looking through ship windows at slightly different depths — nearer windows move
    // more. Pointer events so this also plays on a phone as you scroll/drag past the band.
    safe("portholeParallax", function(){
      var band = document.getElementById("portholeBand");
      if (!band) return;
      var imgs = [
        { el: document.getElementById("phLab"),    fx: 16, fy: 12 },
        { el: document.getElementById("phBlue"),   fx: 24, fy: 16 },
        { el: document.getElementById("phCampus"), fx: 12, fy: 9 }
      ].filter(function(l){ return !!l.el; });
      imgs.forEach(function(l){
        gsap.set(l.el, { scale: 1.22 });
        l.setX = gsap.quickTo(l.el, "x", { duration:.8, ease:"power3.out" });
        l.setY = gsap.quickTo(l.el, "y", { duration:.8, ease:"power3.out" });
      });
      band.addEventListener("pointerenter", function(){ band.classList.add("wc"); });
      // same rAF-batching + quickTo pattern as heroParallax: one applied update per
      // frame no matter how many raw pointermove events the browser delivers.
      var pending = null, ticking = false;
      function apply(){
        ticking = false;
        if (!pending) return;
        var r = band.getBoundingClientRect();
        var cx = ((pending.x - r.left) / r.width) * 2 - 1;
        var cy = ((pending.y - r.top) / r.height) * 2 - 1;
        pending = null;
        imgs.forEach(function(l){ l.setX(cx*l.fx); l.setY(cy*l.fy); });
        gsap.to(band, { "--tiltX": (cy*-3)+"deg", "--tiltY": (cx*3)+"deg", duration:.8, ease:"power3.out", overwrite:true });
      }
      band.addEventListener("pointermove", function(e){
        pending = { x: e.clientX, y: e.clientY };
        if (!ticking){ ticking = true; requestAnimationFrame(apply); }
      }, { passive:true });
      function resetPortholes(){
        pending = null;
        imgs.forEach(function(l){ l.setX(0); l.setY(0); });
        gsap.to(band, { "--tiltX":"0deg", "--tiltY":"0deg", duration:.7, ease:"power2.out", overwrite:true,
          onComplete: function(){ band.classList.remove("wc"); } });
      }
      band.addEventListener("pointerleave", resetPortholes);
      band.addEventListener("pointerup", resetPortholes);
      band.addEventListener("pointercancel", resetPortholes);
    });

    // subtle depth: photos drift slightly as they cross the viewport (same safe non-pinning pattern as the scope panel)
    safe("depth", function(){
      var photos = gsap.utils.toArray(".act-photo img");
      photos.forEach(function(img){
        gsap.set(img, { scale: 1.14, yPercent: -6 });
        ScrollTrigger.create({
          trigger: img.closest(".act-photo"), start: "top bottom", end: "bottom top", scrub: 1,
          onUpdate: function(self){ gsap.set(img, { scale: 1.14, yPercent: -6 + self.progress*12 }); }
        });
      });
    });

    // local banner: a much bigger photo gets a much bigger scroll-parallax travel
    safe("localBanner", function(){
      var img = document.getElementById("istFrontImg");
      var band = document.getElementById("localBanner");
      if (!img || !band) return;
      gsap.set(img, { scale: 1.5, yPercent: -24 });
      ScrollTrigger.create({
        trigger: band, start: "top bottom", end: "bottom top", scrub: .6,
        onUpdate: function(self){ gsap.set(img, { scale: 1.5, yPercent: -24 + self.progress*48 }); }
      });
    });

    // ticker: pure-CSS marquee (see @keyframes tickerScroll) — always runs, even if GSAP
    // fails to load, and stays in sync with the reduced-motion kill-switch above.

    // schedule rail: each day column tilts toward the cursor or a dragging finger, like a
    // physical card — bound to the stable wrapper via delegation since renderSchedule()
    // rebuilds .day-col on every render. Pointer events so this also plays while a phone
    // drags the rail sideways, alongside the existing native/touch scroll.
    safe("scheduleTilt", function(){
      var wrap = document.getElementById("railWrap");
      if (!wrap) return;
      // rAF-batch the raw pointermove events (same idea as the hero/porthole parallax)
      // so this fires at most once per rendered frame no matter how fast the browser
      // delivers them. NOTE: this one stays a plain gsap.to rather than quickTo — quickTo
      // on a 3D-transform property (rotateX/rotateY) combined with a plain y on the same
      // target hits a real recursion bug in GSAP's transform parser ("Maximum call stack
      // size exceeded" in _parseTransform); rAF-batching alone already removes the vast
      // majority of the redundant work, so it isn't needed here for the fix to land.
      var pending = null, ticking = false;
      function apply(){
        ticking = false;
        if (!pending) return;
        var col = pending.col, x = pending.x, y = pending.y;
        pending = null;
        if (!col.isConnected) return;
        col.classList.add("wc");
        var r = col.getBoundingClientRect();
        var cx = ((x - r.left) / r.width) * 2 - 1;
        var cy = ((y - r.top) / r.height) * 2 - 1;
        gsap.to(col, { rotateX: cy*-5, rotateY: cx*5, y:-4, transformPerspective:900, transformOrigin:"center", duration:.5, ease:"power3.out", overwrite:true });
      }
      wrap.addEventListener("pointermove", function(e){
        var col = e.target.closest(".day-col");
        if (!col) return;
        pending = { col: col, x: e.clientX, y: e.clientY };
        if (!ticking){ ticking = true; requestAnimationFrame(apply); }
      }, { passive:true });
      wrap.addEventListener("pointerout", function(e){
        var col = e.target.closest(".day-col");
        if (!col) return;
        if (col.contains(e.relatedTarget)) return;
        if (pending && pending.col === col) pending = null;
        gsap.to(col, { rotateX:0, rotateY:0, y:0, duration:.6, ease:"power2.out", overwrite:true,
          onComplete: function(){ col.classList.remove("wc"); } });
      });
    });

    // sponsors marquee is a plain CSS animation now (see .apoios-track / @keyframes apoiosScroll) —
    // runs on the compositor forever at zero main-thread cost instead of a GSAP tween.

    // team list: a staggered "ladder" — each row eases in from a different offset,
    // scrubbed to scroll position, so the names cascade into place as you pass them.
    // renderTeam() rebuilds #teamList on every language toggle, so this exposes a
    // rebuild hook (mirrors window.__initReveal) that renderTeam() calls after re-render.
    safe("teamLadder", function(){
      var triggers = [];
      function initLadder(){
        triggers.forEach(function(tr){ tr.kill(); });
        triggers = [];
        var rows = gsap.utils.toArray("#teamList .team-row");
        rows.forEach(function(row, i){
          var fromX = (i % 2 === 0) ? -28 : 28;
          var tween = gsap.fromTo(row,
            { x: fromX, opacity: .5 },
            { x: 0, opacity: 1, ease:"none",
              scrollTrigger: { trigger: row, start:"top 92%", end:"top 60%", scrub:.5 } });
          if (tween.scrollTrigger) triggers.push(tween.scrollTrigger);
        });
      }
      window.__rebuildTeamLadder = initLadder;
      if (document.getElementById("teamList").children.length) initLadder();
      else setTimeout(initLadder, 60);
    });

    // batch reveals (elements are already visible at rest; this re-plays them on scroll-in)
    safe("reveal", function(){
      var els;
      function initReveal(){
        els = gsap.utils.toArray("[data-reveal]");
        gsap.set(els, { opacity:0, y:24 });
        ScrollTrigger.batch(els, {
          start: "top 88%",
          onEnter: function(batch){ gsap.to(batch, { opacity:1, y:0, duration:.8, stagger:.08, ease:EASE }); },
          once: true
        });
      }
      // safety net: a jump-to-anchor click (nav links, #hash) or language-toggle
      // re-render can land the scroll position past an element's trigger without
      // firing a scroll event ScrollTrigger can detect a crossing from — catch
      // anything left invisible that's already on screen. Runs continuously off
      // scroll/resize (rAF-throttled) so it self-heals regardless of *why* an
      // element ended up on screen.
      var revealTicking = false;
      function revealVisible(){
        revealTicking = false;
        if (!els) return;
        els.forEach(function(el){
          var op = parseFloat(getComputedStyle(el).opacity);
          if (op < 1 && el.getBoundingClientRect().top < window.innerHeight * 0.95){
            gsap.to(el, { opacity:1, y:0, duration:.5, ease:EASE, overwrite:true });
          }
        });
      }
      function queueReveal(){
        if (revealTicking) return;
        revealTicking = true;
        requestAnimationFrame(revealVisible);
      }
      window.__initReveal = function(){ ScrollTrigger.refresh(); queueReveal(); };
      window.addEventListener("scroll", queueReveal, { passive:true });
      window.addEventListener("resize", queueReveal);
      window.addEventListener("hashchange", queueReveal);
      initReveal();
      queueReveal();
    });

    // final cta bg + scope-photo kenburns are plain CSS animations now (see
    // @keyframes kenburnsBg / kenburnsScope) — same drift, no GSAP ticker cost.

    setTimeout(function(){
      safe("refresh", function(){ ScrollTrigger.refresh(); });
    }, 300);
  } else {
    document.querySelectorAll("[data-reveal]").forEach(function(el){ el.style.opacity=1; });
    clearTimeout(window.__introFailsafe);
    var veilNow = document.getElementById("introVeil");
    if (veilNow && veilNow.parentNode) veilNow.parentNode.removeChild(veilNow);
    document.body.style.overflow = "";
  }

  // custom cursor — a mouse/trackpad affordance; gate on actual pointer capability
  // (not viewport width) so it survives a narrow desktop window and only real
  // touchscreens fall back to the native cursor
  if (window.matchMedia("(hover:hover) and (pointer:fine)").matches){
    var cursor = document.getElementById("cursorDot");
    var label = document.getElementById("cursorLabel");
    var labelText = document.getElementById("cursorLabelText");
    // start off-screen (not center-screen) so the dot never flashes as a static
    // artifact at a fixed spot before the first real pointer move arrives
    var mx = -100, my = -100, cx = mx, cy = my, hasMoved = false;
    window.addEventListener("pointermove", function(e){
      mx = e.clientX; my = e.clientY;
      if (!hasMoved){ hasMoved = true; cx = mx; cy = my; cursor.style.opacity = 1; }
      label.style.transform = "translate("+mx+"px,"+my+"px)";
    }, { passive:true });
    cursor.style.opacity = 0;
    (function raf(){
      cx += (mx-cx)*0.22; cy += (my-cy)*0.22;
      cursor.style.transform = "translate("+cx+"px,"+cy+"px)";
      requestAnimationFrame(raf);
    })();
    function showLabel(text){ labelText.textContent = text; label.style.opacity = 1; }
    function hideLabel(){ label.style.opacity = 0; }
    document.querySelectorAll(".navhover, .cta, .act-row, .final-cta-btn").forEach(function(el){
      el.addEventListener("mouseenter", function(){ showLabel(t().hoverNav || t().hoverCta); });
      el.addEventListener("mouseleave", hideLabel);
    });
  }
})();
