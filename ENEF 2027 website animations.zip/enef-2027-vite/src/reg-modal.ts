// @ts-nocheck
// Registration modal: grow-from-button open/close and step transitions.
// Ported verbatim from the single-file build; remove @ts-nocheck and add types module by module.
(function(){
  var G=window.gsap; if(!G) return;
  var reduce=matchMedia("(prefers-reduced-motion: reduce)").matches;
  var veil=document.getElementById("regModal"), box=veil.querySelector(".modal-box"), src=null;
  veil.style.perspective="1600px";
  document.addEventListener("pointerdown",function(e){ var b=e.target.closest&&e.target.closest("button,a"); if(b&&!veil.contains(b)) src=b; },true);
  document.addEventListener("keydown",function(e){ if((e.key==="Enter"||e.key===" ")&&document.activeElement&&!veil.contains(document.activeElement)) src=document.activeElement; },true);
  function parts(){
    var step=[0,1,2].map(function(i){ return document.getElementById("regStep"+i); }).filter(function(el){ return el&&el.style.display!=="none"; })[0];
    var inner=step?Array.prototype.slice.call(step.children):[];
    return [box.querySelector(".modal-top"),box.querySelector(".modal-bar"),document.getElementById("regTitle")].concat(inner,[box.querySelector(".modal-actions")]).filter(Boolean);
  }
  function fromRect(){
    var b=box.getBoundingClientRect(), r=src&&src.isConnected?src.getBoundingClientRect():null;
    if(!r||!r.width) r={left:innerWidth/2-20,top:innerHeight/2-20,width:40,height:40};
    return { x:(r.left+r.width/2)-(b.left+b.width/2), y:(r.top+r.height/2)-(b.top+b.height/2), sx:Math.max(.02,r.width/b.width), sy:Math.max(.02,r.height/b.height) };
  }
  window.__regOpenFx=function(){
    G.killTweensOf([veil,box]); var p=parts(); G.killTweensOf(p);
    if(reduce){ G.fromTo(veil,{opacity:0},{opacity:1,duration:.25}); return; }
    var f=fromRect();
    G.set(p,{opacity:0});
    G.fromTo(veil,{backgroundColor:"rgba(20,22,26,0)",backdropFilter:"blur(0px)"},{backgroundColor:"rgba(20,22,26,.86)",backdropFilter:"blur(7px)",duration:.6,ease:"power2.out"});
    var tl=G.timeline();
    tl.fromTo(box,{x:f.x,y:f.y,scaleX:f.sx,scaleY:f.sy,rotateX:0,rotateZ:0,backgroundColor:"#1F44FF",transformOrigin:"50% 50%"},
        {keyframes:[
          {x:f.x*.35,y:f.y*.35-40,scaleX:Math.max(f.sx,.55),scaleY:Math.max(f.sy,.08),rotateZ:f.x>0?-4:4,duration:.38,ease:"power3.in"},
          {x:0,y:0,scaleX:1,scaleY:1,rotateZ:0,duration:.62,ease:"expo.out"}
        ]})
      .to(box,{backgroundColor:"#F2EFE7",duration:.35,ease:"none"},.55)
      .fromTo(p,{opacity:0,y:28,rotateX:-50,transformPerspective:700,transformOrigin:"50% 0%"},{opacity:1,y:0,rotateX:0,duration:.7,stagger:.055,ease:"expo.out",clearProps:"transform"},.7)
      .add(function(){ G.set(box,{clearProps:"transform,backgroundColor"}); });
    var fi=box.querySelector("input"); if(fi) setTimeout(function(){ try{ fi.focus({preventScroll:true}); }catch(e){} },1100);
  };
  window.__regCloseFx=function(done){
    if(reduce){ G.to(veil,{opacity:0,duration:.2,onComplete:function(){ G.set(veil,{clearProps:"opacity"}); done(); }}); return; }
    var p=parts(), f=fromRect();
    G.timeline({onComplete:function(){ G.set([box,veil].concat(p),{clearProps:"all"}); done(); }})
      .to(p,{opacity:0,y:-14,duration:.22,stagger:.02,ease:"power2.in"})
      .to(box,{backgroundColor:"#1F44FF",duration:.2},.12)
      .to(box,{x:f.x,y:f.y,scaleX:f.sx,scaleY:f.sy,rotateZ:f.x>0?3:-3,duration:.55,ease:"expo.inOut"},.18)
      .to(veil,{backgroundColor:"rgba(20,22,26,0)",backdropFilter:"blur(0px)",duration:.45},.3);
  };
  window.__regStepFx=function(dir){
    if(reduce) return;
    var p=parts().slice(2);
    G.fromTo(p,{opacity:0,x:dir*60,rotateY:dir*-25,transformPerspective:900},{opacity:1,x:0,rotateY:0,duration:.6,stagger:.04,ease:"expo.out",clearProps:"transform"});
    G.fromTo(box,{rotateY:dir*-6},{rotateY:0,duration:.8,ease:"elastic.out(1,.5)",clearProps:"transform"});
  };
})();
