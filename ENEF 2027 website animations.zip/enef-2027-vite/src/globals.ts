import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

gsap.registerPlugin(ScrollTrigger);

// The ported modules read these from window, exactly like the original <script> tags did.
Object.assign(window, { gsap, ScrollTrigger, L });
