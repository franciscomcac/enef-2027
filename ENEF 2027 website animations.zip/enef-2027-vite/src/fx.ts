// @ts-nocheck
// Particles, cursor trail, intro camera, split titles, flythrough, scroll physics.
// Ported verbatim from the single-file build; remove @ts-nocheck and add types module by module.
/* ===== FX LAYER: particles, camera moves, scroll physics ===== */
(function(){
  "use strict";
  if (matchMedia("(prefers-reduced-motion: reduce)").matches) return;
  var G = window.gsap, ST = window.ScrollTrigger;
  var fine = matchMedia("(hover:hover) and (pointer:fine)").matches;
  var DPR = Math.min(window.devicePixelRatio||1, 1.25);
  var LOW = (navigator.hardwareConcurrency||8) <= 4 || innerWidth < 760 || (navigator.connection && navigator.connection.saveData);
  var mouse = { x:-9999, y:-9999 };
  addEventListener("pointermove", function(e){ mouse.x=e.clientX; mouse.y=e.clientY; }, { passive:true });
  function safe(n,f){ try{ return f(); }catch(e){ console.error("[enef-fx:"+n+"]", e); } }
  function fit(cv){ var r=cv.getBoundingClientRect(); cv.width=Math.max(1,Math.round(r.width*DPR)); cv.height=Math.max(1,Math.round(r.height*DPR)); return r; }
  function whenVisible(el, tick){
    var on=false, raf=0;
    function loop(t){ tick(t); raf=requestAnimationFrame(loop); }
    new IntersectionObserver(function(en){
      var v=en[0].isIntersecting;
      if (v && !on){ on=true; raf=requestAnimationFrame(loop); }
      else if (!v && on){ on=false; cancelAnimationFrame(raf); }
    }).observe(el);
  }
  function debounce(f,ms){ var t; return function(){ clearTimeout(t); t=setTimeout(f,ms); }; }

  // ---- charged-particle field (hero + activities) ----
  function field(o){
    var cv=document.getElementById(o.id); if(!cv) return null;
    var ctx=cv.getContext("2d"), W=0, H=0, pts=[], shocks=[];
    function resize(){
      var r=fit(cv); W=r.width; H=r.height;
      var n=Math.round(Math.min(o.max, W*H/o.density)); pts=[];
      for (var i=0;i<n;i++) pts.push({ x:Math.random()*W, y:Math.random()*H, vx:0, vy:0,
        bx:(Math.random()-.5)*o.speed, by:(Math.random()-.5)*o.speed, r:Math.random()*1.7+.6, a:Math.random()<o.accent });
    }
    resize(); addEventListener("resize", debounce(resize,200));
    var rb=cv.getBoundingClientRect(), upd=function(){ rb=cv.getBoundingClientRect(); };
    addEventListener("scroll", upd, { passive:true }); addEventListener("resize", upd);
    whenVisible(cv, function(){
      var b=rb, mx=mouse.x-b.left, my=mouse.y-b.top, R=o.radius, i, j, p, q, dx, dy, d;
      ctx.setTransform(DPR,0,0,DPR,0,0); ctx.clearRect(0,0,W,H);
      for (i=shocks.length-1;i>=0;i--){ shocks[i].t+=1; if (shocks[i].t>70) shocks.splice(i,1); }
      for (i=0;i<pts.length;i++){
        p=pts[i]; dx=p.x-mx; dy=p.y-my; d=Math.sqrt(dx*dx+dy*dy)||1;
        if (d<R){ var f=(1-d/R)*o.push; p.vx+=dx/d*f; p.vy+=dy/d*f; }
        for (j=0;j<shocks.length;j++){
          var s=shocks[j], sx=p.x-s.x, sy=p.y-s.y, sd=Math.sqrt(sx*sx+sy*sy)||1, ring=s.t*16;
          if (Math.abs(sd-ring)<46){ var k=(1-s.t/70)*2.4; p.vx+=sx/sd*k; p.vy+=sy/sd*k; }
        }
        p.vx*=.94; p.vy*=.94; p.x+=p.vx+p.bx; p.y+=p.vy+p.by;
        if (p.x<-10) p.x=W+10; else if (p.x>W+10) p.x=-10;
        if (p.y<-10) p.y=H+10; else if (p.y>H+10) p.y=-10;
      }
      ctx.lineWidth=1;
      for (i=0;i<pts.length;i++){
        p=pts[i];
        for (j=i+1;j<pts.length;j++){
          q=pts[j]; dx=p.x-q.x; dy=p.y-q.y; d=dx*dx+dy*dy;
          if (d<o.link*o.link){ ctx.globalAlpha=(1-Math.sqrt(d)/o.link)*o.lineA; ctx.strokeStyle=o.lineC; ctx.beginPath(); ctx.moveTo(p.x,p.y); ctx.lineTo(q.x,q.y); ctx.stroke(); }
        }
        dx=p.x-mx; dy=p.y-my; d=Math.sqrt(dx*dx+dy*dy);
        if (d<R*1.25){ ctx.globalAlpha=(1-d/(R*1.25))*o.lineA*2.2; ctx.strokeStyle=o.accentC; ctx.beginPath(); ctx.moveTo(p.x,p.y); ctx.lineTo(mx,my); ctx.stroke(); }
      }
      for (i=0;i<pts.length;i++){
        p=pts[i]; ctx.globalAlpha=p.a?.95:o.dotA; ctx.fillStyle=p.a?o.accentC:o.dotC;
        ctx.beginPath(); ctx.arc(p.x,p.y,p.a?p.r+.6:p.r,0,6.283); ctx.fill();
      }
      for (j=0;j<shocks.length;j++){
        var sh=shocks[j]; ctx.globalAlpha=(1-sh.t/70)*.5; ctx.strokeStyle=o.accentC; ctx.lineWidth=1.5;
        ctx.beginPath(); ctx.arc(sh.x,sh.y,sh.t*16,0,6.283); ctx.stroke(); ctx.lineWidth=1;
      }
      ctx.globalAlpha=1;
    });
    return {
      shock:function(cx,cy){ var b=cv.getBoundingClientRect(); shocks.push({ x:cx-b.left, y:cy-b.top, t:0 }); },
      el:cv
    };
  }

  var heroF = safe("heroField", function(){ return field({ id:"fxHero", max:LOW?40:80, density:9000, speed:.35, accent:.16, radius:150, push:.9, link:115,
    lineC:"#14161A", lineA:.16, dotC:"#14161A", dotA:.42, accentC:"#1F44FF" }); });
  safe("actsField", function(){ var f=field({ id:"fxActs", max:LOW?30:64, density:12000, speed:.25, accent:.2, radius:170, push:.7, link:130,
    lineC:"#F2EFE7", lineA:.12, dotC:"#F2EFE7", dotA:.5, accentC:"#1F44FF" });
    var sec=document.getElementById("atividades"); if (f && sec) sec.addEventListener("pointerdown", function(e){ f.shock(e.clientX,e.clientY); }); });
  var hero=document.getElementById("top");
  if (heroF && hero) hero.addEventListener("pointerdown", function(e){ if (!e.target.closest("button,a")) heroF.shock(e.clientX,e.clientY); });

  // ---- "27" particle formation behind the final CTA ----
  safe("formation", function(){
    var cv=document.getElementById("fxFinal"); if(!cv) return;
    var ctx=cv.getContext("2d"), W=0, H=0, P=[];
    var COLS=["#1F44FF","#1F44FF","#1F44FF","#F2EFE7","#C4362F","#E8A93C","#2C93A8","#4B3FA6"];
    function build(){
      var r=fit(cv); W=r.width; H=r.height; if (W<10||H<10) return;
      var off=document.createElement("canvas"); off.width=W; off.height=H;
      var o=off.getContext("2d"), fs=Math.min(H*.95, W*.6);
      o.font=fs+"px Anton, Impact, sans-serif"; o.textAlign="right"; o.fillStyle="#000";
      o.fillText("27", W*.97, H*.42+fs*.36);
      var d=o.getImageData(0,0,W,H).data, gap=W<700?5:7, T=[];
      for (var y=0;y<H;y+=gap) for (var x=0;x<W;x+=gap) if (d[(y*W+x)*4+3]>128) T.push([x,y]);
      while (T.length>(LOW?600:1100)) T=T.filter(function(_,i){ return i%2===0; });
      var old=P; P=T.map(function(t,i){
        var p=old[i]||{ x:Math.random()*W, y:Math.random()*H, vx:0, vy:0, c:COLS[(Math.random()*COLS.length)|0], s:Math.random()<.12?2.6:1.8 };
        p.tx=t[0]; p.ty=t[1]; return p;
      });
    }
    (document.fonts && document.fonts.load ? document.fonts.load("100px Anton") : Promise.resolve()).then(build, build);
    addEventListener("resize", debounce(build,250));
    whenVisible(cv, function(t){
      var b=cv.getBoundingClientRect(), mx=mouse.x-b.left, my=mouse.y-b.top;
      ctx.setTransform(DPR,0,0,DPR,0,0); ctx.clearRect(0,0,W,H);
      for (var i=0;i<P.length;i++){
        var p=P[i], dx=p.x-mx, dy=p.y-my, d=Math.sqrt(dx*dx+dy*dy)||1;
        if (d<130){ var f=(1-d/130)*7; p.vx+=dx/d*f; p.vy+=dy/d*f; }
        var wob=Math.sin(t*.0015+p.ty*.02)*1.2;
        p.vx+=(p.tx+wob-p.x)*.016; p.vy+=(p.ty-p.y)*.016; p.vx*=.86; p.vy*=.86;
        p.x+=p.vx; p.y+=p.vy;
        ctx.fillStyle=p.c; ctx.fillRect(p.x,p.y,p.s,p.s);
      }
    });
  });

  // ---- cursor spark trail in the four day colours ----
  safe("cursorTrail", function(){
    if (!fine || LOW) return;
    var cv=document.getElementById("fxCursor"); if(!cv) return;
    var ctx=cv.getContext("2d"), S=[], lx=null, ly=null, W, H;
    var COLS=["#1F44FF","#C4362F","#E8A93C","#2C93A8","#4B3FA6"];
    var DPR=1; function rs(){ W=innerWidth; H=innerHeight; cv.width=W; cv.height=H; } rs(); addEventListener("resize", rs);
    addEventListener("pointermove", function(e){
      if (lx!==null){
        var dx=e.clientX-lx, dy=e.clientY-ly, n=Math.min(6, Math.floor(Math.sqrt(dx*dx+dy*dy)/7));
        for (var i=0;i<n;i++) S.push({ x:e.clientX-dx*i/n, y:e.clientY-dy*i/n, vx:(Math.random()-.5)*1.6-dx*.04, vy:(Math.random()-.5)*1.6-dy*.04+.2, l:1, r:Math.random()*2.2+1, c:COLS[(Math.random()*COLS.length)|0] });
      }
      lx=e.clientX; ly=e.clientY;
      if (!running && S.length){ running=true; requestAnimationFrame(loop); }
    }, { passive:true });
    var running=false;
    var dirty=false;
    function loop(){
      if (S.length || dirty){
        ctx.setTransform(DPR,0,0,DPR,0,0); ctx.clearRect(0,0,W,H); dirty=S.length>0;
        for (var i=S.length-1;i>=0;i--){
          var s=S[i]; s.x+=s.vx; s.y+=s.vy; s.vy+=.04; s.l-=.028;
          if (s.l<=0){ S.splice(i,1); continue; }
          ctx.globalAlpha=s.l; ctx.fillStyle=s.c; ctx.beginPath(); ctx.arc(s.x,s.y,s.r*s.l,0,6.283); ctx.fill();
        }
        ctx.globalAlpha=1;
        if (S.length>220) S.splice(0,S.length-220);
      }
      if (S.length || dirty) requestAnimationFrame(loop); else running=false;
    }
  });

  if (!G || !ST){ var fs=document.getElementById("flyScene"); if (fs) fs.style.display="none"; return; }

  // ---- intro camera: hero dollies in from a tilted, pulled-back angle as the veil clears ----
  safe("introCamera", function(){
    if (!hero) return;
    var hadVeil=!!document.getElementById("introVeil");
    var d=hadVeil?1.95:0;
    G.fromTo(hero, { transformPerspective:1400, transformOrigin:"50% 0%", rotateX:18, scale:1.1, y:90 },
      { rotateX:0, scale:1, y:0, duration:1.9, ease:"expo.out", delay:d, clearProps:"transform" });
    if (heroF) setTimeout(function(){ var b=hero.getBoundingClientRect(); heroF.shock(b.left+b.width/2, b.top+Math.min(b.height,innerHeight)/2); }, d*1000+150);
    setTimeout(function(){ var bl=document.querySelector(".wordmark .row.blue"); if (bl) bl.classList.add("glitch"); }, d*1000+2400);
  });

  // ---- wordmark letters: elastic squash on hover ----
  safe("wordmarkJelly", function(){
    document.querySelectorAll("#heroWordmark .row span").forEach(function(s){
      s.addEventListener("pointerenter", function(){
        G.timeline().to(s, { y:"-0.16em", scaleY:1.14, scaleX:.92, rotate:(Math.random()-.5)*10, duration:.16, ease:"power2.out" })
          .to(s, { y:0, scaleY:1, scaleX:1, rotate:0, duration:.9, ease:"elastic.out(1,.3)" });
      });
    });
  });

  // ---- split-char 3D title reveals (re-split after language toggle) ----
  safe("splitTitles", function(){
    function split(el){
      if (el.__splitHTML === el.innerHTML) return;
      var nodes=Array.prototype.slice.call(el.childNodes); el.innerHTML="";
      var chars=[];
      nodes.forEach(function(n){
        if (n.nodeType===3){
          n.textContent.split(/(\s+)/).forEach(function(w){
            if (!w) return;
            if (/^\s+$/.test(w)){ el.appendChild(document.createTextNode(" ")); return; }
            var ws=document.createElement("span"); ws.className="split-w";
            Array.from(w).forEach(function(c){ var cs=document.createElement("span"); cs.className="split-c"; cs.textContent=c; ws.appendChild(cs); chars.push(cs); });
            el.appendChild(ws);
          });
        } else el.appendChild(n);
      });
      el.__splitHTML=el.innerHTML;
      G.fromTo(chars, { yPercent:90, rotateX:-95, opacity:0, transformPerspective:600, transformOrigin:"50% 100%" },
        { yPercent:0, rotateX:0, opacity:1, duration:1.1, stagger:.022, ease:"expo.out",
          scrollTrigger:{ trigger:el, start:"top 88%", once:true } });
    }
    function all(){ document.querySelectorAll(".sec-title, .final-title").forEach(split); }
    all();
    var prev=window.__initReveal;
    window.__initReveal=function(){ if (prev) prev(); all(); };
  });

  // ---- magnetic CTAs ----
  safe("magnetic", function(){
    if (!fine) return;
    document.querySelectorAll(".final-cta-btn, nav .cta").forEach(function(btn){
      var sx=G.quickTo(btn,"x",{duration:.5,ease:"power3.out"}), sy=G.quickTo(btn,"y",{duration:.5,ease:"power3.out"});
      btn.addEventListener("pointermove", function(e){ var r=btn.getBoundingClientRect(); sx((e.clientX-r.left-r.width/2)*.38); sy((e.clientY-r.top-r.height/2)*.38); });
      btn.addEventListener("pointerleave", function(){ sx(0); sy(0); });
    });
  });

  // ---- scroll-velocity skew on marquees and team list ----
  safe("velocitySkew", function(){
    var targets=[document.getElementById("tickerWrap"), document.querySelector(".apoios-track"), ].filter(Boolean);
    targets.forEach(function(t){ t.style.willChange="transform"; });
    var sets=targets.map(function(t){ return G.quickSetter(t,"skewX","deg"); });
    var proxy={ s:0 };
    ST.create({ onUpdate:function(self){
      var s=G.utils.clamp(-14,14,self.getVelocity()/-220);
      if (Math.abs(s)>Math.abs(proxy.s)){
        proxy.s=s;
        G.to(proxy, { s:0, duration:.9, ease:"power3", overwrite:true, onUpdate:function(){ sets.forEach(function(f){ f(proxy.s); }); } });
      }
    }});
  });

  // ---- dark sections open like an aperture as they arrive ----
  safe("apertures", function(){
    [].forEach(function(sel){
      var el=document.querySelector(sel); if(!el) return;
      G.fromTo(el, { clipPath:"inset(5% 4% 0% 4% round 36px)" }, { clipPath:"inset(0% 0% 0% 0% round 0px)", ease:"none",
        scrollTrigger:{ trigger:el, start:"top bottom", end:"top 25%", scrub:.6 } });
    });
    G.utils.toArray(".act-photo").forEach(function(ph){
      G.fromTo(ph, { clipPath:"inset(0% 100% 0% 0%)" }, { clipPath:"inset(0% 0% 0% 0%)", duration:1.3, ease:"expo.inOut",
        scrollTrigger:{ trigger:ph, start:"top 88%", once:true } });
    });


  });

  // ---- flythrough: pinned scroll-driven camera travelling through Lisbon in Z ----
  safe("flythrough", function(){
    var scene=document.getElementById("flyScene"), stage=document.getElementById("flyStage"), world=document.getElementById("flyWorld");
    if (!scene) return;
    var GAP=1000, items=G.utils.toArray("#flyWorld .fly-item").map(function(el,i){
      return { el:el, x:+el.dataset.x||0, y:+el.dataset.y||0, r:+el.dataset.r||0, z:-(i+1)*GAP };
    });
    var total=items.length*GAP, cam={ v:0 }, vel=0, swX=0, swY=0;
    var zEl=document.getElementById("flyZ"), bar=document.getElementById("flyBar");
    function render(){
      var vw=innerWidth/100, vh=innerHeight/100;
      swX+=((mouse.x/innerWidth-.5)-swX)*.06; swY+=((mouse.y/innerHeight-.5)-swY)*.06;
      if (!isFinite(swX)) swX=0; if (!isFinite(swY)) swY=0;
      stage.style.perspectiveOrigin=(50+G.utils.clamp(-.5,.5,swX)*30)+"% "+(50+G.utils.clamp(-.5,.5,swY)*30)+"%";
      world.style.transform="rotateZ("+(Math.sin(cam.v/2600)*4)+"deg)";
      for (var i=0;i<items.length;i++){
        var it=items[i], z=it.z+cam.v, o;
        if (z>220) o=Math.max(0,1-(z-220)/480);
        else if (z<-6000) o=0;
        else if (z<-3800) o=(z+6000)/2200;
        else o=1;
        it.el.style.visibility=o<=0?"hidden":"visible";
        if (o<=0) continue;
        it.el.style.opacity=o;
        it.el.style.transform="translate(-50%,-50%) translate3d("+(it.x*vw)+"px,"+(it.y*vh)+"px,"+z+"px) rotate("+it.r+"deg)";
      }
      if (zEl) zEl.textContent="Z "+String(Math.round(cam.v)).padStart(5,"0");
      if (bar) bar.style.width=(cam.v/total*100)+"%";
    }
    G.to(cam, { v:total, ease:"none", scrollTrigger:{ trigger:scene, start:"top top", end:function(){ return "+="+Math.round(innerHeight*3.4); },
      pin:true, scrub:1, anticipatePin:1, refreshPriority:1, onUpdate:function(self){ vel=self.getVelocity(); } } });
    render();
    // warp-speed starfield, velocity-coupled to the scroll
    var cv=document.getElementById("flyStars"), ctx=cv.getContext("2d"), W, H, stars=[];
    function rs(){ var r=fit(cv); W=r.width; H=r.height; stars=[]; for (var i=0;i<(LOW?80:150);i++) stars.push(newStar(true)); }
    function newStar(any){ return { x:(Math.random()*2-1)*W, y:(Math.random()*2-1)*H, z:any?Math.random()*W:W, pz:0, a:Math.random()<.14 }; }
    rs(); addEventListener("resize", debounce(rs,200));
    whenVisible(scene, function(){
      render();
      vel*=.94;
      var sp=2+Math.min(70, Math.abs(vel)/40), cx=W/2+swX*-60, cy=H/2+swY*-60, fov=W*.5;
      ctx.setTransform(DPR,0,0,DPR,0,0); ctx.clearRect(0,0,W,H);
      for (var i=0;i<stars.length;i++){
        var s=stars[i], pz=s.z; s.z-=sp;
        if (s.z<1){ stars[i]=newStar(false); continue; }
        var x1=s.x/pz*fov+cx, y1=s.y/pz*fov+cy, x2=s.x/s.z*fov+cx, y2=s.y/s.z*fov+cy;
        if (x2<-50||x2>W+50||y2<-50||y2>H+50){ stars[i]=newStar(false); continue; }
        var k=1-s.z/W;
        ctx.globalAlpha=Math.min(1,k*1.3); ctx.strokeStyle=s.a?"#1F44FF":"#F2EFE7"; ctx.lineWidth=k*2.4+.3;
        ctx.beginPath(); ctx.moveTo(x1,y1); ctx.lineTo(x2,y2); ctx.stroke();
      }
      ctx.globalAlpha=1;
    });
  });

  setTimeout(function(){ ST.refresh(); }, 450);
  if (document.fonts && document.fonts.ready) document.fonts.ready.then(function(){ ST.refresh(); });
})();
