// PT / EN copy for the whole site (navigation, programme, packs, schedule, FAQ, registration).
// eslint-disable-next-line @typescript-eslint/no-explicit-any
export const COPY: Record<'pt' | 'en', any> = {
    pt: {
      navProg:"Programa", navPacks:"Packs", navSched:"Horário", navTeam:"Equipa", navFaqs:"FAQ", navPlace:"Local", navContact:"Contactos",
      navPacksNum:"Packs", navSchedNum:"Horário", navTeamNum:"Equipa", navFaqsNum:"FAQ", navPlaceNum:"Local", navContactNum:"Contactos",
      cta:"Inscrever", ctaLong:"Inscreve-te →", ctaPack:"Inscrever com este pack", hoverNav:"Ver secção", hoverCta:"Abrir inscrição", back:"Voltar",
      kicker:"Encontro Nacional de Estudantes de Física",
      ticker:["ENEF 2027","Lisboa","11—14 fevereiro","Inscrições abertas","26ª edição","Técnico"],
      aside:"vemo-nos em lisboa",
      heroLead:"A 26ª edição do ENEF acontece em Lisboa, no Instituto Superior Técnico. Quatro dias de física, cidade e gente nova.",
      rec:"Ao vivo", until:"até ao evento",
      actTitle:"Ciência de dia,\nLisboa de noite.",
      actSub:"Três frentes de programa, quatro dias, uma cidade que não fecha cedo.",
      activities:[
        {title:"Científicas", body:"Palestras de investigadores, workshops práticos e visitas aos laboratórios do Técnico.", tag:"Palestras · Workshops · Labs", img:LAB_IMG},
        {title:"Recreativas", body:"Jantares, noites lisboetas e roteiros pela cidade. O ENEF também se faz fora das salas.", tag:"Noites · Roteiros · Jantares", img:BLUE_IMG},
        {title:"Concursos", body:"Poster Competition e Student Lectures. Apresenta o teu trabalho e habilita-te a prémios.", tag:"Posters · Student Lectures", img:CAMPUS_IMG}
      ],
      stats:[["26ª","Edição"],["40+","Palestras e workshops"],["300","Participantes"]],
      packTitle:"Cinco packs.", packSub:"Do bilhete só para a ciência ao pack completo com alojamento. Preços da 1ª fase.",
      packs:[
        {code:"P1", name:"Científicas", price:"35€", includes:[0]},
        {code:"P2", name:"Científicas + refeições", price:"60€", includes:[0,1]},
        {code:"P3", name:"Científicas + recreativas", price:"65€", includes:[0,2]},
        {code:"P4", name:"Científicas + recreativas + refeições", price:"90€", includes:[0,1,2]},
        {code:"P5", name:"Tudo + alojamento", price:"120€", includes:[0,1,2,3]}
      ],
      incl:["Atividades científicas","Refeições","Atividades recreativas","Alojamento"],
      summaryLabel:"Resumo da inscrição", totalLabel:"Total",
      trust1:"Sem taxas escondidas", trust2:"Cancela até 30 dias antes", trust3:"Pagamento confirmado por email em 48h",
      schedTitle:"Quatro dias,\num horário.", dragHint:"Arrasta para o lado →",
      dayLabels:["11","12","13","14"], dayWeek:["QUI","SEX","SÁB","DOM"],
      schedule:[
        [["14:00","Check-in e credenciação","Pavilhão de Física"],["17:00","Sessão de abertura","Anfiteatro Abreu Faro"],["18:30","Palestra de abertura","Anfiteatro Abreu Faro"],["21:30","Jantar de boas-vindas","Alameda"],["23:30","Noite de abertura","Bairro Alto"]],
        [["09:30","Palestras plenárias","Anfiteatro Abreu Faro"],["11:30","Workshops paralelos","Departamento de Física"],["14:30","Visitas a laboratórios","Campus Alameda"],["17:00","Poster Competition","Átrio do Complexo"],["22:00","Noite temática","Cais do Sodré"]],
        [["09:30","Student Lectures","Anfiteatro Abreu Faro"],["11:30","Painel com empresas","Sala de Congressos"],["15:00","Roteiro por Lisboa","Baixa e Belém"],["20:00","Jantar de gala","Lisboa"],["23:30","Festa ENEF","Lisboa"]],
        [["10:00","Assembleia Physis","Departamento de Física"],["12:00","Entrega de prémios","Anfiteatro Abreu Faro"],["13:00","Sessão de encerramento","Anfiteatro Abreu Faro"],["14:30","Almoço de despedida","Alameda"]]
      ],
      teamTitle:"Quem organiza.",
      roles:["Coordenação","Logística","Científico","Comunicação","Parcerias","Recreativo","Financeiro","Design"],
      faqTitle:"Perguntas frequentes.",
      faqs:[
        ["Quem se pode inscrever?","O ENEF é aberto a estudantes de física e áreas afins de qualquer instituição de ensino superior, do 1º ano ao doutoramento."],
        ["O alojamento está incluído?","Só no pack completo. Nos restantes packs a organização partilha uma lista de alojamentos com desconto perto do campus."],
        ["Posso mudar de pack depois de me inscrever?","Sim, até 30 dias antes do evento, mediante disponibilidade e pagamento da diferença."],
        ["Há apoio a deslocações?","Estamos a negociar tarifas de grupo com operadores ferroviários. Serão anunciadas por email a quem estiver inscrito."],
        ["Como submeto um poster ou uma student lecture?","A submissão abre em novembro de 2026 através do formulário de inscrição. Podes indicar interesse já na inscrição."]
      ],
      placeBody:"Todas as sessões científicas decorrem no Departamento de Física do Técnico, no campus da Alameda. Metro à porta, cidade a dez minutos.",
      placeDept:"Departamento de Física · Campus Alameda",
      placeCap:"Pavilhão Central · Alameda",
      sponsorsLabel:"Apoios e patrocínios",
      finalTitle:"Vemo-nos em Lisboa.",
      finalSub:"O maior encontro de estudantes de física em Portugal. Inscrições da 1ª fase abertas até 30 de novembro de 2026.",
      footCols:[
        ["Onde",["Instituto Superior Técnico","Departamento de Física, Campus Alameda","Av. Rovisco Pais 1, 1049-001 Lisboa"]],
        ["Quando",["11 a 14 de fevereiro de 2027","Quatro dias, uma cidade"]],
        ["Quem organiza",["Physis — Núcleo de Física","Ver equipa completa acima"]]
      ],
      reg:{
        steps:["Dados","Pack","Confirmação"], t1:"Quem és tu?", t2:"Escolhe o teu pack", t3:"Inscrição registada.",
        fields:[["Nome completo","Ex: Ana Silva"],["Email","Ex: ana@exemplo.pt"],["Instituição","Ex: Instituto Superior Técnico"]],
        next:"Continuar", finish:"Confirmar inscrição", close:"Fechar",
        doneBody:"Recebemos a tua inscrição. Vais receber um email com os dados de pagamento nas próximas 48 horas."
      }
    },
    en: {
      navProg:"Programme", navPacks:"Packs", navSched:"Schedule", navTeam:"Team", navFaqs:"FAQ", navPlace:"Venue", navContact:"Contact",
      navPacksNum:"Packs", navSchedNum:"Schedule", navTeamNum:"Team", navFaqsNum:"FAQ", navPlaceNum:"Venue", navContactNum:"Contact",
      cta:"Register", ctaLong:"Register now →", ctaPack:"Register with this package", hoverNav:"See section", hoverCta:"Open registration", back:"Back",
      kicker:"National Meeting of Physics Students",
      ticker:["ENEF 2027","Lisbon","11—14 February","Registration open","26th edition","Técnico"],
      aside:"see you in lisbon",
      heroLead:"The 26th edition of ENEF takes place in Lisbon, at Instituto Superior Técnico. Four days of physics, city and new people.",
      rec:"Live", until:"to the event",
      actTitle:"Science by day,\nLisbon by night.",
      actSub:"Three programme strands, four days, a city that does not close early.",
      activities:[
        {title:"Scientific", body:"Talks by researchers, hands-on workshops and visits to Técnico laboratories.", tag:"Talks · Workshops · Labs", img:LAB_IMG},
        {title:"Social", body:"Dinners, Lisbon nights and city routes. ENEF happens outside the lecture halls too.", tag:"Nights · Routes · Dinners", img:BLUE_IMG},
        {title:"Competitions", body:"Poster Competition and Student Lectures. Present your work and compete for prizes.", tag:"Posters · Student Lectures", img:CAMPUS_IMG}
      ],
      stats:[["26th","Edition"],["40+","Talks and workshops"],["300","Participants"]],
      packTitle:"Five packages.", packSub:"From the science-only ticket to the full package with accommodation. First-phase prices.",
      packs:[
        {code:"P1", name:"Scientific", price:"€35", includes:[0]},
        {code:"P2", name:"Scientific + meals", price:"€60", includes:[0,1]},
        {code:"P3", name:"Scientific + social", price:"€65", includes:[0,2]},
        {code:"P4", name:"Scientific + social + meals", price:"€90", includes:[0,1,2]},
        {code:"P5", name:"Everything + accommodation", price:"€120", includes:[0,1,2,3]}
      ],
      incl:["Scientific activities","Meals","Social activities","Accommodation"],
      summaryLabel:"Registration summary", totalLabel:"Total",
      trust1:"No hidden fees", trust2:"Cancel up to 30 days before", trust3:"Payment confirmed by email within 48h",
      schedTitle:"Four days,\none schedule.", dragHint:"Drag sideways →",
      dayLabels:["11","12","13","14"], dayWeek:["THU","FRI","SAT","SUN"],
      schedule:[
        [["14:00","Check-in and badges","Physics Building"],["17:00","Opening session","Abreu Faro Hall"],["18:30","Opening lecture","Abreu Faro Hall"],["21:30","Welcome dinner","Alameda"],["23:30","Opening night","Bairro Alto"]],
        [["09:30","Plenary lectures","Abreu Faro Hall"],["11:30","Parallel workshops","Physics Department"],["14:30","Laboratory visits","Alameda Campus"],["17:00","Poster Competition","Main Atrium"],["22:00","Themed night","Cais do Sodré"]],
        [["09:30","Student Lectures","Abreu Faro Hall"],["11:30","Industry panel","Congress Hall"],["15:00","Lisbon city route","Baixa and Belém"],["20:00","Gala dinner","Lisbon"],["23:30","ENEF party","Lisbon"]],
        [["10:00","Physis assembly","Physics Department"],["12:00","Awards ceremony","Abreu Faro Hall"],["13:00","Closing session","Abreu Faro Hall"],["14:30","Farewell lunch","Alameda"]]
      ],
      teamTitle:"Who organises it.",
      roles:["Coordination","Logistics","Scientific","Communication","Partnerships","Social","Finance","Design"],
      faqTitle:"Frequently asked.",
      faqs:[
        ["Who can register?","ENEF is open to physics and related students from any higher education institution, from first year to PhD."],
        ["Is accommodation included?","Only in the full package. For the other packages we share a list of discounted places near campus."],
        ["Can I change package after registering?","Yes, up to 30 days before the event, subject to availability and payment of the difference."],
        ["Is there travel support?","We are negotiating group fares with rail operators. Registered participants will be notified by email."],
        ["How do I submit a poster or student lecture?","Submissions open in November 2026 through the registration form. You can flag your interest when you register."]
      ],
      placeBody:"All scientific sessions take place at the Physics Department of Técnico, on the Alameda campus. Metro at the door, city ten minutes away.",
      placeDept:"Physics Department · Alameda Campus",
      placeCap:"Central Pavilion · Alameda",
      sponsorsLabel:"Partners and sponsors",
      finalTitle:"See you in Lisbon.",
      finalSub:"Portugal's largest gathering of physics students. First-phase registration open until 30 November 2026.",
      footCols:[
        ["Where",["Instituto Superior Técnico","Physics Department, Alameda Campus","Av. Rovisco Pais 1, 1049-001 Lisbon"]],
        ["When",["11 to 14 February 2027","Four days, one city"]],
        ["Organised by",["Physis — Physics Student Society","See full team above"]]
      ],
      reg:{
        steps:["Details","Package","Confirmation"], t1:"Who are you?", t2:"Choose your package", t3:"Registration received.",
        fields:[["Full name","Ex: Ana Silva"],["Email","Ex: ana@example.com"],["Institution","Ex: Instituto Superior Técnico"]],
        next:"Continue", finish:"Confirm registration", close:"Close",
        doneBody:"We received your registration. You will get an email with payment details within 48 hours."
      }
    }
  };
