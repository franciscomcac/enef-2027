// @ts-nocheck
// Live Leaflet map of IST with fly-in.
// Ported verbatim from the single-file build; remove @ts-nocheck and add types module by module.
(function(){
  var el=document.getElementById("istMap"); if(!el) return;
  var img=document.querySelector(".local-r img.map-img");
  function init(){
    if(!window.L){ el.remove(); return; }
    if(img) img.style.display="none";
    var ll=[38.7367,-9.1395], mobile=L.Browser.mobile;
    var map=L.map(el,{ center:ll, zoom:16, minZoom:13, maxZoom:18, scrollWheelZoom:false, dragging:!mobile, tap:false, attributionControl:false, zoomControl:true });
    map.zoomControl.setPosition("bottomright");
    L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png",{ attribution:"© OpenStreetMap contributors", maxZoom:19, detectRetina:false }).addTo(map);
    L.marker(ll,{ icon:L.divIcon({ className:"", iconSize:[0,0], html:'<div class="ist-pin"><i></i><i></i><i></i><b></b><span>Técnico</span></div>' }), keyboard:false }).addTo(map);
    // camera move: fly in from the city when the map scrolls into view
    map.setView([38.7223,-9.1393],13,{animate:false});
    new IntersectionObserver(function(en,ob){ if(en[0].isIntersecting){ ob.disconnect(); setTimeout(function(){ map.flyTo(ll,16,{duration:2.2}); },200); } },{threshold:.4}).observe(el);
    addEventListener("resize",function(){ map.invalidateSize(); });
  }
  // only boot Leaflet when the section is close
  new IntersectionObserver(function(en,ob){ if(en[0].isIntersecting){ ob.disconnect(); init(); } },{rootMargin:"600px"}).observe(el);
})();
