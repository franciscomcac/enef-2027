/// <reference types="vite/client" />
import type { gsap as GSAP } from 'gsap';
import type { ScrollTrigger as ST } from 'gsap/ScrollTrigger';
import type * as Leaflet from 'leaflet';

declare global {
  interface Window {
    gsap: typeof GSAP;
    ScrollTrigger: typeof ST;
    L: typeof Leaflet;
    __initReveal?: () => void;
    __packBurst?: (i: number) => void;
    __regOpenFx?: () => void;
    __regCloseFx?: (done: () => void) => void;
    __regStepFx?: (dir: number) => void;
  }
}
export {};
