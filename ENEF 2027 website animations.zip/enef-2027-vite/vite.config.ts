import { defineConfig } from 'vite';

export default defineConfig({
  // public/assets/* keeps its original URLs (assets/photo1.jpg …); Vite's hashed output goes to /static
  build: { assetsDir: 'static', target: 'es2020' },
});
